/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysqlconnection;

/**
 *
 * @author Abbas.Mehdi
 */
public class MySqlConnection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        DBConnection con = new DBConnection();
        String insertd = con.InsertData(0004,"SAEED hu", "HUSSAIN");
        System.out.println( insertd );
        
        con.GetData();
    }
    
}
