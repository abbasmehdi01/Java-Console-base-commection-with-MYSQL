/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysqlconnection;
import java.sql.*;
/**
 *
 * @author Abbas.Mehdi
 */
public class DBConnection 
{
    private Connection conn;
    private Statement st;
    private ResultSet rs;
    
    public DBConnection()
    {
         try
         {
             Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost/test","root","");
             st = conn.createStatement();
         }
         catch (Exception ex)
         {
             System.out.println("Error ==> " + ex);
         }            
    }
    
    public void GetData()
    {
         try
         {
             String sql = "Select * from test" ;
             rs =st.executeQuery(sql);
             System.out.println(" Records from Database " );
             
             while(rs.next())
              {
                String id       = rs.getString("id");
                String name     = rs.getString("name");
                String name2    = rs.getString("name2");
                System.out.println(" id = " + id +" name = " + name +" name2 = " + name2);
              }
                     
         }
         catch (Exception ex)
         {
             System.out.println("Error ==> " + ex);
         }            
    }   

public String InsertData(int id , String name, String name2)
    {
         try
         {
             String sql = "insert into test VALUES("+id+",'" +name+"','" +name2+ "')" ;
             st.executeUpdate(sql);
             return " Records from Database " ;
             
         }
         catch (Exception ex)
         {
             return " Error ==> " + ex;
         }            
    }    
}
